package ado2;

public class exercicio4 {

}
