package ado2;
import javax.swing.JOptionPane;
public class exe1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float valor1= Integer.parseInt(
				JOptionPane.showInputDialog("Digite o valor 1 �"));
		float valor2 =Integer.parseInt(
				JOptionPane.showInputDialog("Digite o valor 2� "));
		float valor3 =Integer.parseInt(
				JOptionPane.showInputDialog("Digite o valor 3� "));
		System.out.println(" O valor deo produto desses valores � de :"+ (valor1 +valor2+valor3));
	}


	}


