package listadeexercicios2;

import java.util.Scanner;

public class exercicio4 {
	public static void main(String[] args) {
		
	for (int contador = 10; contador <=1000;contador=contador+10) {		
		System.out.println(contador);
		
	}

}
}