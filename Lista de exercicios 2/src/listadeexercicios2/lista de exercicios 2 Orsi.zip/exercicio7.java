package listadeexercicios2;

public class exercicio7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int numero = 7;
	       int i = 0;
	       
	        System.out.println("Os M�ltiplos de 7 menores que 200 s�o: ");
	       
	       while (i <= 27) {
	           i++;
	           System.out.println(numero * i);
	}

}
}