package listadeexercicios2;

public class exercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int contador = 1;
		while (contador  <=50) {
			System.out.println(contador);
			contador++;
	}

}
}
