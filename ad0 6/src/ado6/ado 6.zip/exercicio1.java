package ado6;

public class exercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
		while (i<101) {
				System.out.println(i);
				i= i+2;
		}
}

	}


