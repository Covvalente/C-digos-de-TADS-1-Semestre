package ado6;

public class exercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=0;
		for (x=1;x<110;x++) {
			System.out.println(x);
			x=x+1;
	}

}
}
