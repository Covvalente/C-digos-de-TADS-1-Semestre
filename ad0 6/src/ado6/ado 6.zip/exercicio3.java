package ado6;

public class exercicio3 {

	public static void main(String[] args) {
		
int x=100;
		
		for( x= 100; 	x>= 5; x--) {
		System.out.println(x);
		x = x-4;
	}
}
}