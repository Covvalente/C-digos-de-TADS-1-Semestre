package lista4;

public class exe1 {
	    public static void main(String[] args){

	        int vetor [] = {2, 3, 4, 5, 6, 7};

	        for (int i = 0; i < vetor.length; i++) {
	            System.out.println(vetor[i]);

	        }
	    }
	}


