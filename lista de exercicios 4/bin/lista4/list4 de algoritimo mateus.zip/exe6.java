package lista4;

public class exe6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 float vetor[] = { 5,6,3,4,2,8};
		 float S=1;
		 for (int i=0;i<vetor.length;i++) {
			 S=S*vetor[i];
			 
		 }
		 System.out.println("Produto do vetor : "+S);
	}

}
