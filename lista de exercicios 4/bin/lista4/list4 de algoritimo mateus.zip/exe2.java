package lista4;

public class exe2 {
	

	    public static void main(String[] args){

	        float[] vetor = {2, 3, 4, 5, 6, 7};
	        float S = 0;

	        for (int i = 0; i < vetor.length; i++) {

	            S = S + vetor[i];
	            System.out.println(S);


	        }
	    }
	}



