package Lista1Algoristmos;

import java.util.Scanner;

public class Ex2 
{
  public static void main(String[] args) {
   
      Scanner leitor = new 
  Scanner(System.in);
      System.out.println("Digite a base base ");
      float base = leitor.nextFloat();
      System.out.println("Digite o expoente ");
      float expoente = leitor.nextFloat();
      double potencia = Math.pow(base, expoente);
      System.out.println("A potencia dos dois n�meros � de :" + potencia);
   
  }

}
