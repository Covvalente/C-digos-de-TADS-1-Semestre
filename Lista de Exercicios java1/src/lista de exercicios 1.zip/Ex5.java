package Lista1Algoristmos;

import java.util.Scanner;

public class Ex5 {

 public static void main(String[] args) 
 {
  
  Scanner lado = new Scanner (System.in);
  System.out.println("Digite o valor L do quadrado ");
  float L = lado.nextFloat();
  System.out.println("A area do quadrado � de :" + (L * L) );
  

 }

}