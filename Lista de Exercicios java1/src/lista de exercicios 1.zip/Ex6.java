package Lista1Algoristmos;


import java.util.Scanner;

public class Ex6 {

 public static void main(String[] args) 
 {
	 double n1 = 0, n2 = 0, n3 = 0;
	 double pi = 3.14159;
	 double area;
	 double peri;
	 
	 Scanner leitor = new Scanner (System.in);
	 
	 System.out.println("Digite o valor de A");
	 n1 = leitor.nextDouble();
	 System.out.println("Digite o valor de B");
	 n2 = leitor.nextDouble();
	 System.out.println("Digite o valor de C");
	 n3 = leitor.nextDouble();
	 
	 area = (n1 * n3)/2;
	 System.out.println("A �rea do tri�ndulo ret�ngulo �: " + area);
  
	 area = pi * (n3 * n3);
	 System.out.println("A �rea do c�rculo �: " + area);
	 
	 area = (n1 * n2) * n3/2;
	 System.out.println("A �rea do trap�zio �: " + area);
	 
	 area = (n2 * n2);
	 System.out.println("A �rea do quadrado �:" + area);
	 
	 area = (n1 * n2);
	 System.out.println("A �rea do ret�ngulo �:" + area);
	 
	 peri = (n1 * 2) + (n2 * 2);
	 System.out.println("O per�metro do ret�ngulo �:" + peri);

}

}