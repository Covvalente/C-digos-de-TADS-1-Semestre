package Lista1Algoritmos;

import java.util.Scanner;

public class Ex14 {

 public static void main(String[] args) {
  int n1 = 0;
  int n2 = 0;
  
  Scanner sc = new Scanner(System.in);
  
  System.out.println("Digite o primeiro n�mero");
  n1 = sc.nextInt();
  
  System.out.println("Digite o segundo n�mero");
  n2 = sc.nextInt();
  
  if (n1 > n2) {
	  System.out.println("O resultado do " + n1 + " dividido pelo " + n2 + " �: " + n1/n2);}
  else if (n1 < n2) {
		  System.out.println("O resultado do " + n2 + " dividido pelo " + n1 + " �: " + n2/n1);
		  
  		} 
  
 	}
}


