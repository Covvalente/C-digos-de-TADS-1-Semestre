package Lista1Algoristmos;

import java.util.Scanner;

public class Ex10 {

 public static void main(String[] args)
{
  Scanner leitor = new Scanner(System.in);
  System.out.println("Qual o seu nome? ");
  String n = leitor.next();
  System.out.println("Qual o seu sal�rio fixo? ");
  float sf = leitor.nextFloat();
  System.out.println("Quantas reais em vendas voce efetuou nesse mes? ");
  float v = leitor.nextFloat();

  double c = (v * 0.15) ;
  
  System.out.println("Nome: " + n + ". Sal�rio fixo: " + sf + ". Total de comissao: " + c + "R$" + ". Total a receber no mes: " + (c + sf) );
 }

}
