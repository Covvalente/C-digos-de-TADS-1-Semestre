package Lista1Algoristmos;

import java.util.Scanner;

public class Ex12 {

	public static void main(String[] args) {
		double L = 0;
		double R = 0;
		float Pi = 3.14f;
		double area;
		double circ;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite o valor do lado");
		L = sc.nextDouble();
		
		
		

	}

}
