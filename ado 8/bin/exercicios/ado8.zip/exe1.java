package exercicios;



public class exe1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String [] Vetorum= {"jan","fev","mar","abr","mai","jun","jul","ago","set","out","nov","dez"};
		String [] Vetordois= new String [Vetorum.length];
	for(int i=0;i<Vetorum.length;i++) {
		Vetordois[i]=Vetorum[i];
		System.out.println(Vetordois[i]+"");
		}
		
		}
	}


