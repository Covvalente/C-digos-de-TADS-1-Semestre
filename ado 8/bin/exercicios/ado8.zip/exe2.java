package exercicios;

class exe2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	int [] vetor1 = {2,4,7,6,5,};
		int[] vetor2 = {5,4,1,2,3};
	int [] vetor3 = new int [vetor1.length];
		
			for(int i=0  ;i<vetor1.length; i++) {
		System.out.println(vetor3 [i] = vetor1[i]+vetor2 [i ] );
		System.out.println("");
		
		}
				
	}

}
